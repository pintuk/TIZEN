/*
 * =============================================================================
 *
 * SLP
 * Copyright (c) 2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung Electronics.
 *
 * @file:  overlay_test.c
 * @brief:  Spreadtrum overlay test file (OSD)
 * @author:  Harsh Aggarwal (a.harsh), a.harsh@samsung.com
 * @created:  Saturday 23 November 2013 01:22:17  IST
 * @compiler:  gcc
 * @company:  Samsung
 * @version:  0.1
 * @revision:  none
 *
 * =============================================================================
 */

#include <fcntl.h>
#include <errno.h>
#include <stdint.h>
#include <sys/ioctl.h>
#include <stdbool.h>
#include <sys/mman.h>
#include <unistd.h>
#include <linux/fb.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <tbm_bufmgr.h>
#include <video/sprd_fb.h>

#define SPRD_DRI_DEV "/dev/dri/card0"
#define SPRD_FB_DEV "/dev/fb0"
#define OVERLAY_BUF_NUM 2
typedef struct _hwc_context_t {
  /* our private state goes below here */
    int fbfd;
    int fb_width;
    int fb_height;
  //the following are for osd overlay layer
} hwc_context_t;

typedef struct _hwc_layer {
	int id;
	uint32_t ion_fd;
}hwc_layer_t;


static int init_fb_parameter(hwc_context_t *context)
{
	struct fb_fix_screeninfo finfo;
	int fd = -1;

	fd = open(SPRD_FB_DEV, O_RDWR);
	if (fd < 0)
	{
		perror("fail to open fb\n");
		return -errno;
	}

	if (ioctl(fd, FBIOGET_FSCREENINFO, &finfo) == -1)
	{
		printf("fail to get fb finfo\n");
		return -errno;
	}

	struct fb_var_screeninfo info;
	if (ioctl(fd, FBIOGET_VSCREENINFO, &info) == -1)
	{
		printf("fail to get fb info\n");
		return -errno;
	}
	context->fbfd = fd;
	context->fb_width = info.xres;
	context->fb_height = info.yres;
	printf("fb_width = %d,fb_height = %d\n",context->fb_width,context->fb_height);
	return 0;
}

int dri_open()
{
        int fd = open(SPRD_DRI_DEV, O_RDWR);//NO_CACHING
        if (fd < 0)
                printf("open %s failed!\n", SPRD_DRI_DEV);

	printf("%s ionfd = %d\n", __func__, __LINE__);
        return fd;
}

int dri_close(int fd)
{
        return close(fd);
}

static int display_osd_layer (hwc_context_t *ctx) {
		int layer_indexs = 0;
		struct overlay_display_setting display_setting;
		layer_indexs |= SPRD_LAYERS_OSD;
		display_setting.display_mode = SPRD_DISPLAY_OVERLAY_SYNC;
		display_setting.layer_index = layer_indexs;
		display_setting.rect.x = 0;
		display_setting.rect.y = 0;
		display_setting.rect.w = ctx->fb_width;
		display_setting.rect.h = ctx->fb_height;
		printf("SPRD_FB_DISPLAY_OVERLAY %d, [%d,%d,%d,%d]\n", layer_indexs,\
 			       	display_setting.rect.x, display_setting.rect.y, display_setting.rect.w, display_setting.rect.h);
		if (ioctl(ctx->fbfd, SPRD_FB_DISPLAY_OVERLAY, &display_setting) == -1) {
			fprintf(stderr, "===fail osd SPRD_FB_DISPLAY_OVERLAY\n");
			return -1;
		}
	return 0;
}

static int set_osd_layer(hwc_context_t *context, hwc_layer_t * l)
{
	struct overlay_setting ov_setting;
	uint32_t ion_fd = l->ion_fd;
	ov_setting.layer_index = SPRD_LAYERS_OSD;
	ov_setting.data_type = SPRD_DATA_FORMAT_RGB888;
	ov_setting.y_endian = SPRD_DATA_ENDIAN_B3B2B1B0;
	ov_setting.uv_endian = SPRD_DATA_ENDIAN_B3B2B1B0;

	ov_setting.rb_switch = 1;
	ov_setting.rect.x = 0;
	ov_setting.rect.y = 0;
	ov_setting.rect.w = context->fb_width;
	ov_setting.rect.h = context->fb_height;
	ov_setting.ion_fd = ion_fd;
	printf("osd overlay parameter datatype = %d,x=%d,y=%d,w=%d,h=%d,ionfd=%d\n",\
			ov_setting.data_type,ov_setting.rect.x,ov_setting.rect.y,ov_setting.rect.w,ov_setting.rect.h,ov_setting.ion_fd);
	if (ioctl(context->fbfd, SPRD_FB_SET_OVERLAY, &ov_setting) == -1)
	{
		fprintf(stderr, "===fail osd SPRD_FB_SET_OVERLAY\n");
	}
	return 0;	
}

void memset32(void *pDst, uint32_t Value, int Count)
{
	uint8_t *ptr = pDst, *endptr;
	uint8_t w,x,y,z;

	endptr = ptr+4*Count;
	w = Value & 0xFF; x = (Value >> 8) & 0xFF; y = (Value >> 16) & 0xFF; z = (Value >> 24) & 0xFF;

	while(ptr < endptr){
		*ptr++ = w;
		*ptr++ = x;
		*ptr++ = y;
		*ptr++ = z;
	}
}

int paintBuffer(unsigned char *buffer, unsigned int width, unsigned int height, unsigned int line_length)
{
	unsigned int row;
	uint32_t longColorVal;
	static int index = 0;
	//BGRA
	if (index % 3 == 0) {
		longColorVal = 0xFF0000A0;
	}
	else if  (index % 3 == 1) {
		longColorVal = 0x00FF00A0;
	}
	else  {
		longColorVal = 0x0000FFA0;
	}

	for (row = 0; row < height; row++)
            	memset32(buffer+line_length*row, longColorVal, width);

	index++;
	return 0;
}
int main(int argc, const char *argv[])
{
	hwc_context_t *context = (hwc_context_t *) calloc(1, sizeof(hwc_context_t));
	hwc_layer_t *layer = (hwc_layer_t *) calloc(1, sizeof(hwc_layer_t));
	unsigned char *ptr;
	int alloc_size = 0;

	init_fb_parameter(context);

	int drmFd = dri_open();
	int overlay_buf_size = context->fb_width * context->fb_height * 4;

  	/* get buffer manager */
    	setenv("BUFMGR_LOCK_TYPE", "never", 1);
    	setenv("BUFMGR_MAP_CACHE", "false", 1);

	tbm_bufmgr bufmgr = tbm_bufmgr_init(drmFd);
	alloc_size = overlay_buf_size*OVERLAY_BUF_NUM;
	tbm_bo bo = tbm_bo_alloc(bufmgr,alloc_size, TBM_BO_DEFAULT);
	ptr = tbm_bo_get_handle(bo, TBM_DEVICE_CPU).ptr;
	layer->ion_fd = tbm_bo_get_handle(bo, TBM_DEVICE_2D).s32; 

	while (1) {
		paintBuffer(ptr,context->fb_width, context->fb_height, context->fb_width*4);
		set_osd_layer (context, layer);
		display_osd_layer  (context);
	}

	tbm_bo_unmap(bo);
	tbm_bo_unref(bo);

	tbm_bufmgr_deinit(bufmgr);
	dri_close(drmFd);
	close (context->fbfd);
	free(context);
	free(layer);
	return 0;
}
