/*
 * main.c
 *
 * Author:
 * Himanshu Sheth <himanshu.s@samsung.com>
 * Mugdha <mugdha.g@samsung.com>
 *
 *
 */ 

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <dirent.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <sys/inotify.h>
#ifdef CONFIG_STANDALONE_EXE
#include "limits.h"
#include <unistd.h>
#else
#include <sys/limits.h>
#endif

#include <sys/poll.h>
#include <errno.h>

#include <linux/input.h>

#define BUFSIZE 25

extern int playback_main(int argc, char *argv[]);
extern int record_main(int argc, char *argv[]);
extern int touchinput_main(int argc, char *argv[]);

static void usage(int argc, char *argv[])
{
    fprintf(stderr, "****** Touch Command ********\n");
    fprintf(stderr, "use: %s <touch-event device> "
			"<x coordinate> <y coordinate>\n", argv[0]);
    fprintf(stderr, "****** Record Command ********\n");
    fprintf(stderr, "usage: %s -f <event file> [-t <touch-key dev node>]"
                    "[-s <touch screen dev node>] [-k <keyboard  dev node>]"
                    "[-g <gpio key dev node>]\n", argv[0]);
    fprintf(stderr, "mentioning atleast one dev node is mandatory\n");					
    fprintf(stderr, "****** Playback Command ********\n");
    fprintf(stderr, "usage: %s -f <event file> [-t <touch-key dev node>]"
                    "[-s <touch screen dev node>] [-k <keyboard  dev node>]"
                    "[-g <gpio key dev node>]\n", argv[0]);
    fprintf(stderr, "mentioning atleast one dev node is mandatory\n");
}

int main(int argc, char *argv[])
{
    int i, fd,c;
	char buf[BUFSIZE+1];
    snprintf(buf,BUFSIZE,"%s",optarg);
	
	memset(buf, '\0',sizeof(buf));
	
    do {
	   c = getopt(argc, argv, "x:");

	   if (c == EOF)
	       break;
		   
	   snprintf(buf,BUFSIZE,"%s",optarg);
	   /* printf("Optional Argument is [%s]\n",buf); */
		   
	   if (strcmp(buf, "play") == 0) {
	          playback_main(argc, argv);
		  break;
	   }
	   else if (strcmp(buf, "record") == 0) {
	          record_main(argc, argv);
		  break;
	   }
	   else if (strcmp(buf, "touchinput") == 0) {
	          touchinput_main(argc, argv);
		  break;
	   }
	   else if (strcmp(buf, "?") == 0) {
                 fprintf(stderr, "%s: invalid option -%c\n", argv[0], optopt);
		 break;
	   }
	   else if (strcmp(buf, "h") == 0) {
	         usage(argc, argv);
                 exit(1);
	   }
	   else {
	   	 usage(argc, argv);
                 exit(1);
	   }
	} while (1);   
}
