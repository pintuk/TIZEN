/*
 * record.c - program for recording the events
 *
 * Author:
 *       Geetika Bajpai <geetika.b@samsung.com>
 * Info:
 * - To build this sourcefile as part of toolbox no change is required.
 * - To build it as standalone executable define CONFIG_STANDALONE_EXE.
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <dirent.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <sys/inotify.h>

#ifdef CONFIG_STANDALONE_EXE
#include "limits.h"
#include <unistd.h>
#else
#include <sys/limits.h>
#endif

#include <sys/poll.h>
#include <errno.h>

#include <linux/input.h>

#define timeval_msec(tv)        ((tv.tv_sec * 1000) + (tv.tv_usec/1000))
#define timeval_usec(tv)        ((tv.tv_sec * 1000000) + (tv.tv_usec))

enum
{
    TOUCH_KEY        = 1,
    TOUCH_SCRN,
    KEYBOARD_IN,
    GPIO_IN
};

static struct pollfd *ufds;
static char **device_names;
static int nfds;
static FILE *rec_file;
char rec_file_loc[512];

enum {
    PRINT_DEVICE_ERRORS     = 1U << 0,
    PRINT_DEVICE            = 1U << 1,
    PRINT_DEVICE_NAME       = 1U << 2,
};


static int open_device(const char *device, int print_flags)
{
    int fd;
    struct pollfd *new_ufds;
    char **new_device_names;
    char name[80];
    struct input_id id;

    fd = open(device, O_RDWR);

    if (fd < 0) {
        if (print_flags & PRINT_DEVICE_ERRORS)
            fprintf(stderr, "could not open %s, %s\n", device, strerror(errno));
        return -1;
    }

    name[sizeof(name) - 1] = '\0';

    if (ioctl(fd, EVIOCGNAME(sizeof(name) - 1), &name) < 1)
        name[0] = '\0';

    new_ufds = realloc(ufds, sizeof(ufds[0]) * (nfds + 1));

    if (new_ufds == NULL) {
        fprintf(stderr, "out of memory\n");
        return -1;
    }

    ufds = new_ufds;
    new_device_names = realloc(device_names, sizeof(device_names[0]) * (nfds + 1));

    if (new_device_names == NULL) {
        fprintf(stderr, "out of memory\n");
        return -1;
    }

    device_names = new_device_names;
    ufds[nfds].fd = fd;
    ufds[nfds].events = POLLIN;
    device_names[nfds] = strdup(device);
    nfds++;
    return 0;
}

int rec_close_device(const char *device, int print_flags)
{
    int i;

    for (i = 1; i < nfds; i++) {

        if (strcmp(device_names[i], device) == 0) {
            int count = nfds - i - 1;
            if (print_flags & PRINT_DEVICE)
                printf("remove device %d: %s\n", i, device);

            free(device_names[i]);
            memmove(device_names + i, device_names + i + 1, sizeof(device_names[0]) * count);
            memmove(ufds + i, ufds + i + 1, sizeof(ufds[0]) * count);
            nfds--;
            return 0;
        }
    }

    if (print_flags & PRINT_DEVICE_ERRORS)
        fprintf(stderr, "remote device: %s not found\n", device);
    return -1;
}

static int read_notify(const char *dirname, int nfd, int print_flags)
{
    int res;
    char devname[PATH_MAX];
    char *filename;
    char event_buf[512];
    int event_size;
    int event_pos = 0;
    struct inotify_event *event;

    res = read(nfd, event_buf, sizeof(event_buf));

    if (res < (int)sizeof(*event)) {
        if (errno == EINTR)
            return 0;
        fprintf(stderr, "could not get event, %s\n", strerror(errno));
        return 1;
    }

    strcpy(devname, dirname);
    filename = devname + strlen(devname);
    *filename++ = '/';

    while (res >= (int)sizeof(*event)) {
        event = (struct inotify_event *)(event_buf + event_pos);

        if (event->len) {
            strcpy(filename, event->name);

            if (event->mask & IN_CREATE)
                open_device(devname, print_flags);
            else
                rec_close_device(devname, print_flags);
        }

        event_size = sizeof(*event) + event->len;
        res -= event_size;
        event_pos += event_size;
    }
    return 0;
}

static int scan_dir(const char *dirname, int print_flags)
{
    char devname[PATH_MAX];
    char *filename;
    DIR *dir;
    struct dirent *de;

    dir = opendir(dirname);

    if (dir == NULL)
        return -1;

    strcpy(devname, dirname);
    filename = devname + strlen(devname);
    *filename++ = '/';

    while ((de = readdir(dir))) {

        if (de->d_name[0] == '.' &&
            (de->d_name[1] == '\0' ||
             (de->d_name[1] == '.' && de->d_name[2] == '\0')))
             continue;

        strcpy(filename, de->d_name);
        open_device(devname, print_flags);
    }

    closedir(dir);
    return 0;
}

static void usage(int argc, char *argv[])
{
    fprintf(stderr, "usage: %s -f <event file> [-t <touch-key dev node>]"
                    "[-s <touch screen dev node>] [-k <keyboard  dev node>]"
                    "[-g <gpio key dev node>]\n", argv[0]);
    fprintf(stderr, "mentioning atleast one dev node is mandatory\n");
}

int update_file(int i, struct timeval *prev_timeval, int map_val)
{
    struct input_event event;
    static long int p_time_msec;
    long int time_msec = 0;
    int res;
    char *newline = "\n";

    if (ufds[i].revents) {
        if (ufds[i].revents & POLLIN) {
            res = read(ufds[i].fd, &event, sizeof(event));
            if (res < (int)sizeof(event)) {
                fprintf(stderr, "could not get event\n");
                return 1;
            }

            if ((prev_timeval->tv_sec == 0) && (prev_timeval->tv_usec == 0)) {
                fprintf(rec_file, "0 ");
                prev_timeval->tv_sec = event.time.tv_sec;
                prev_timeval->tv_usec = event.time.tv_usec;
                p_time_msec = timeval_usec(event.time);
            } else {
                time_msec = timeval_usec(event.time);
                fprintf(rec_file, "%ld ", (time_msec - p_time_msec));
                p_time_msec = time_msec;
            }

            fprintf(rec_file, "%d ", map_val);
            fprintf(rec_file, "%x %x %x", event.type, event.code, event.value);
            fprintf(rec_file, "%s", newline);
            fflush(rec_file);
        }
    }
    return 0;
}

#ifdef CONFIG_STANDALONE_EXE
int record_main(int argc, char *argv[])
#endif
{
    int c;
    int i;
    int j;
    int res;
    int pollres;
    int print_flags = 0;
    int print_flags_set = 0;
    struct timeval prev_timeval;
    const char *device = NULL;
    const char *device_path = "/dev/input";
    struct devices {
        char dev_name[20];
        int map;
    } dv[20];
    int match = -1;
    int count = 0;
    int ret;

    opterr = 0;

    do {
        c = getopt(argc, argv, "f:t:s:k:g:h");

        if (c == EOF)
           break;

        switch (c) {

        case 'f':
            memset(&prev_timeval, 0, sizeof(struct timeval));
            strcpy(rec_file_loc, optarg);
            break;

        case 't':
            strcpy(dv[count].dev_name, optarg);
            dv[count].map = TOUCH_KEY;
            count++;
            break;

        case 's':
            strcpy(dv[count].dev_name, optarg);
            dv[count].map = TOUCH_SCRN;
            count++;
            break;

        case 'k':
            strcpy(dv[count].dev_name, optarg);
            dv[count].map = KEYBOARD_IN;
            count++;
            break;

        case 'g':
            strcpy(dv[count].dev_name, optarg);
            dv[count].map = GPIO_IN;
            count++;
            break;

        case '?':
            fprintf(stderr, "%s: invalid option -%c\n", argv[0], optopt);

        case 'h':
            usage(argc, argv);
            exit(1);
        }
    } while (1);

    if ((optind != argc) || (argc < 4)) {
        usage(argc, argv);
        exit(1);
    }

    rec_file = fopen(rec_file_loc, "w");

    if (rec_file == NULL) {
        fprintf(stderr, "44Could not open the file4 %s\n", rec_file_loc);
        return 1;
    }

    nfds = 1;
    ufds = calloc(1, sizeof(ufds[0]));
    ufds[0].fd = inotify_init();
    ufds[0].events = POLLIN;

    if (device) {
        if (!print_flags_set)
            print_flags |= PRINT_DEVICE_ERRORS;

        res = open_device(device, print_flags);

        if (res < 0)
            return 1;
    } else {
        if (!print_flags_set)
            print_flags |= PRINT_DEVICE_ERRORS | PRINT_DEVICE | PRINT_DEVICE_NAME;

        res = inotify_add_watch(ufds[0].fd, device_path, IN_DELETE | IN_CREATE);

        if (res < 0) {
            fprintf(stderr, "could not add watch for %s, %s\n", device_path, strerror(errno));
            return 1;
        }

        res = scan_dir(device_path, print_flags);

        if (res < 0) {
            fprintf(stderr, "scan dir failed for %s\n", device_path);
            return 1;
        }
    }

    while (1) {
        pollres = poll(ufds, nfds, -1);
        if (ufds[0].revents & POLLIN)
            read_notify(device_path, ufds[0].fd, print_flags);

        for (i = 1; i < nfds; i++) {
            for (j = 0; j < count; j++) {
                match = strcmp(dv[j].dev_name, device_names[i]);

                if (match == 0) {
                    ret = update_file(i, &prev_timeval, dv[j].map);
                    if (ret == 1)
                        return 1;
                    match = -1;
                    break;
                }
            }
        }
    }

    printf("End of program\n");
    return 0;
}
