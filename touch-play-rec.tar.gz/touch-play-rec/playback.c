/*
 * playback.c - program for playing back recorded event file
 *
 * Author:
 *       Geetika Bajpai <geetika.b@samsung.com>
 * Info:
 * - To build this sourcefile as part of toolbox no change is required.
 * - To build it as standalone executable define CONFIG_STANDALONE_EXE.
 * - To disable touch boost comment the macro ENABLE_TOUCH_BOOST.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <errno.h>
#define EVIOCGVERSION    _IOR('E', 0x01, int) /* get driver version */
#ifdef CONFIG_STANDALONE_EXE
#include <linux/input.h>
#include <unistd.h>
#else
struct input_event {
    struct timeval time;
    __u16 type;
    __u16 code;
    __s32 value;
};
#endif
/*#define ENABLE_TOUCH_BOOST*/

enum
{
    TOUCH_KEY         = 1,
    TOUCH_SCRN,
    KEYBOARD_IN,
    GPIO_IN
};

char line[256];

static void usage(int argc, char *argv[])
{
    fprintf(stderr, "Usage: %s -f <event file> [-t <touch-key dev node>] "
                    "[-s <touch screen dev node>] "
                    "[-k <keyboard  dev node>] "
                    "[-g <gpio key dev node>]\n", argv[0]);
}

#ifdef CONFIG_STANDALONE_EXE
int playback_main(int argc, char *argv[])
#endif
{
    int i;
    int c;
    int fd[25];
    int virt_fd_2_real_fd[25];
    int ret;
    int version;
    struct input_event event;
    FILE *ev_file;
    char ev_file_loc[512];
    long int delay;
    int dev_id;
    struct devices {
        char dev_name[20];
        int map;
        int actual;
    } dv[20];
    int count = 0;
    unsigned int type;
    unsigned int code;

    #ifdef ENABLE_TOUCH_BOOST
    FILE *tb_file;
    __s32 prev_value = 0;
    int new_event = 1;
    char c_val;
    #define TB_FILE_LOC "/sys/kernel/tb_user/tch_bst"
    #endif

    for (i = 0; i < 25; i++)
        virt_fd_2_real_fd[i] = -1;

    do {
        c = getopt(argc, argv, "f:t:s:k:g:h");
        if (c == EOF)
            break;

        switch (c) {

        case 'f':
            strcpy(ev_file_loc, optarg);
            break;

        case 't':
            strcpy(dv[count].dev_name, optarg);
            dv[count].actual = atoi(&dv[count].dev_name[16]);
            dv[count].map = TOUCH_KEY;
            virt_fd_2_real_fd[TOUCH_KEY] = atoi(&dv[count].dev_name[16]);
            count++;
            break;

        case 's':
            strcpy(dv[count].dev_name, optarg);
            dv[count].actual = atoi(&dv[count].dev_name[16]);
            dv[count].map = TOUCH_SCRN;
            virt_fd_2_real_fd[TOUCH_SCRN] = atoi(&dv[count].dev_name[16]);
            count++;
            break;

        case 'k':
            strcpy(dv[count].dev_name, optarg);
            dv[count].actual = atoi(&dv[count].dev_name[16]);
            dv[count].map = KEYBOARD_IN;
            virt_fd_2_real_fd[KEYBOARD_IN] = atoi(&dv[count].dev_name[16]);
            count++;
            break;

        case 'g':
            strcpy(dv[count].dev_name, optarg);
            dv[count].actual = atoi(&dv[count].dev_name[16]);
            dv[count].map = GPIO_IN;
            virt_fd_2_real_fd[GPIO_IN] = atoi(&dv[count].dev_name[16]);
            count++;
            break;

        case '?':
            fprintf(stderr, "%s: invalid option -%c\n", argv[0], optopt);

        case 'h':
        default:
            usage(argc, argv);
            exit(1);
        }
    } while (1);

    if (optind != argc) {
        usage(argc, argv);
        exit(1);
    }

    ev_file = fopen(ev_file_loc, "r");

    if (ev_file == NULL) {
        fprintf(stderr, "Could not open the file1 %s\n", ev_file_loc);
        return 1;
    }

    #ifdef ENABLE_TOUCH_BOOST
    tb_file = fopen(TB_FILE_LOC, "w");

    if (tb_file == NULL) {
        fprintf(stderr, "Could not open the file2 %s\n", TB_FILE_LOC);
        return 1;
    }
    #endif

    /* Open all fds and file */

    for (i = 0; i < count; i++) {
        fd[dv[i].actual] = open(dv[i].dev_name, O_RDWR);
        if (fd[dv[i].actual] < 0) {
            fprintf(stderr, "could not open %s, %s\n",
                    dv[i].dev_name, strerror(errno));
            fclose(ev_file);
            #ifdef ENABLE_TOUCH_BOOST
	    fclose(tb_file);
            #endif
            return 1;
        }

        if (ioctl(fd[dv[i].actual], EVIOCGVERSION, &version)) {
            fprintf(stderr, "could not get driver version for %s, %s\n",
                    dv[i].dev_name, strerror(errno));
            fclose(ev_file);
            #ifdef ENABLE_TOUCH_BOOST
	    fclose(tb_file);
            #endif
            return 1;
        }
    }

    while ((fgets(line, sizeof line, ev_file) != NULL)) {
        memset(&event, 0, sizeof(event));
        sscanf(line, "%10ld %3d %4u %8x %8x",
               &delay, &dev_id, &type, &code, &event.value);
        event.type = type;
        event.code = code;
        #ifdef ENABLE_TOUCH_BOOST
        if (dev_id == 2) {
            if (new_event == 1) {
                c_val = '1';
                fprintf(tb_file, "%c\n", c_val);
                fflush(tb_file);
                new_event = 0;
	    }
            if (event.type == 0 && event.code == 0 &&
                event.value == 0 && prev_value == -1){
                c_val = '0';
                fprintf(tb_file, "%c\n", c_val);
                fflush(tb_file);
                new_event = 1;
            }
        }
        #endif
        dev_id = virt_fd_2_real_fd[dev_id];
        if (dev_id != -1 ) {
            usleep(delay);
            ret = write(fd[dev_id], &event, sizeof(event));
            if (ret < (int)sizeof(event))
                fprintf(stderr, "write event failed, %s, %s\n",
                        line, strerror(errno));
        }
        #ifdef ENABLE_TOUCH_BOOST
        prev_value = event.value;
        #endif
    }

    for (i = 0; i < count; i++)
        close(fd[dv[i].actual]);

    fclose(ev_file);
    #ifdef ENABLE_TOUCH_BOOST
    fclose(tb_file);
    #endif
    return 0;
}
