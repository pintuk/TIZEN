#include<stdio.h>
#include<stdlib.h>
#include<string.h>

FILE *fp=NULL;

#define BLOCK_WIDTH		32
#define BLOCK_HEIGHT		32
#define NUM_BLOCK		32
#define IMAGE_WIDTH		((BLOCK_WIDTH*NUM_BLOCK)+((NUM_BLOCK+1)*2))
#define IMAGE_HEIGHT		((BLOCK_HEIGHT*NUM_BLOCK)+((NUM_BLOCK+1)*2))
#define IMAGE_SIZE		(IMAGE_WIDTH*IMAGE_HEIGHT)
#define Y_BLK_SPACING		2
#define CBCR_BLK_SPACING	(Y_BLK_SPACING >> 1)

//#define IMAGE_SIZE	(84*84*2)

#define BACKGROUND_COLOR	0x80



long int movablepages = 0;
long int reclaimablepages = 0;


typedef enum YUVcolor {
	BLACK_YCOLOR=0x10,
	BLACK_CBCOLOR=0x80,
	BLACK_CRCOLOR=0x80,
	GREY_YCOLOR=0xEB,
	GREY_CBCOLOR=0x80,
	GREY_CRCOLOR=0x80,
	RED_YCOLOR=0x51,
	RED_CBCOLOR=0x5A,
	RED_CRCOLOR=0xF0,
	BLUE_YCOLOR=0x29,
	BLUE_CBCOLOR=0xF0,
	BLUE_CRCOLOR=0x6E,
}yuvcolortype;

typedef struct color_type {
	unsigned char ycolor;
	unsigned char cbcolor;
	unsigned char crcolor;
}colortype;


typedef struct YUVformat {
	unsigned char *y;
	unsigned char *u;
	unsigned char *v;
	unsigned int width;
	unsigned int height;
}yuvformat;


//static int fillblock(unsigned char*y_buf,unsigned char*cb_buf, unsigned char*cr_buf, unsigned int wd, unsigned int ht, colortype color)
static int fillblock(yuvformat *yuv, colortype color)
{
        unsigned int i=0,j=0,k=0;
        unsigned int cbcr_wd = 0, cbcr_ht = 0;
	unsigned int wd=0,ht=0;
        unsigned char *temp_buf = NULL;
	

	wd = (unsigned int)BLOCK_WIDTH;
	ht = (unsigned int)BLOCK_HEIGHT;
/*
	for(i=0; i<ht; i++)
	{
		for(j=0; j<wd; j++)
		{
			//memset(yuv->y, color.ycolor, wd);
			yuv->y[i++] = color.ycolor;
			if(ht%2==0 && wd%2==0)
			{
				//memset(yuv->u, color.cbcolor, wd>>1);
				//memset(yuv->v, color.crcolor, wd>>1);
				yuv->u[j++] = color.cbcolor;
				yuv->v[k++] = color.crcolor;
			}
		}
	}
*/

///*
        cbcr_wd = (wd >> 1);
        cbcr_ht = (ht >> 1);
//Y
        temp_buf = yuv->y;
        for(i=0;i<ht;i++)
        {
                memset(temp_buf, color.ycolor, wd);
                temp_buf += yuv->width;
        }
//Cb
        temp_buf = yuv->u;
        for(i=0;i<cbcr_ht;i++)
        {
                memset(temp_buf, color.cbcolor, cbcr_wd);
                temp_buf += (yuv->width >> 1);
        }
//Cr
        temp_buf = yuv->v;
        for(i=0;i<cbcr_ht;i++)
        {
                memset(temp_buf, color.crcolor, cbcr_wd);
                temp_buf += (yuv->width >> 1);
        }
//*/
	
	return 0;
}


static void create_blocks(yuvformat *yuv)
{
	unsigned char *temp_y_data = NULL,*temp_cb_data = NULL,*temp_cr_data = NULL;
	unsigned int i=0,j=0,k=0;
	colortype clr;

	//yuv->y  = yuv->y + (Y_BLK_SPACING*yuv->width) + Y_BLK_SPACING;
	//yuv->u = yuv->u + (yuv->width * yuv->height)  + (CBCR_BLK_SPACING * (yuv->width/2)) + CBCR_BLK_SPACING;
	//yuv->v = yuv->v + (yuv->width * yuv->height)  + ((yuv->width/2) * (yuv->height/2)) + CBCR_BLK_SPACING * (yuv->width/2) + CBCR_BLK_SPACING;
	
	temp_y_data = yuv->y;
	temp_cb_data = yuv->u;
	temp_cr_data = yuv->v;
	
	clr.ycolor = GREY_YCOLOR;
	clr.cbcolor = GREY_CBCOLOR;
	clr.crcolor = GREY_CRCOLOR;
	for(i=1;i<=(unsigned int)NUM_BLOCK;i++) // start the loop from 1 only. 
	{
		for(j=0;j<(unsigned int)NUM_BLOCK;j++)
		{
			//fillblock(y_data, cb_data, cr_data, (unsigned int)BLOCK_WIDTH, (unsigned int)BLOCK_HEIGHT, clr);
			if(movablepages > 0)
			{
				clr.ycolor = RED_YCOLOR;
				clr.cbcolor = RED_CBCOLOR;
				clr.crcolor = RED_CRCOLOR;
				fillblock(yuv, clr);
				movablepages--;
			}
			else if(reclaimablepages > 0)
			{
				clr.ycolor = BLUE_YCOLOR;
				clr.cbcolor = BLUE_CBCOLOR;
				clr.crcolor = BLUE_CRCOLOR;
				fillblock(yuv, clr);
				reclaimablepages--;
			}
			else
			{
				clr.ycolor = GREY_YCOLOR;
				clr.cbcolor = GREY_CBCOLOR;
				clr.crcolor = GREY_CRCOLOR;
				fillblock(yuv, clr);
			}
			yuv->y  += ((unsigned int)BLOCK_WIDTH)+ Y_BLK_SPACING;
			yuv->u += ((unsigned int)(BLOCK_WIDTH >> 1)) + CBCR_BLK_SPACING;
			yuv->v += ((unsigned int)(BLOCK_WIDTH >> 1)) + CBCR_BLK_SPACING;
		}
		yuv->y = temp_y_data  + (yuv->width * ((unsigned int)BLOCK_WIDTH + Y_BLK_SPACING) * i);
		yuv->u = temp_cb_data + ((yuv->width>>1) * ((unsigned int)(BLOCK_WIDTH >> 1) + CBCR_BLK_SPACING) * i);
		yuv->v = temp_cr_data + ((yuv->width>>1) * ((unsigned int)(BLOCK_WIDTH >> 1) + CBCR_BLK_SPACING) * i);
		//printf("block done....(%d)\n",i);
	}
}


void create_background(yuvformat *yuv, colortype color)
{
	unsigned int i=0,j=0,k=0,w=0,h=0;

	for(h=0; h < yuv->height; h++)
	{
		for(w=0; w < yuv->width; w++)
		{
			yuv->y[i++] = color.ycolor;
			if(h%2==0 && w%2==0)
			{
				yuv->u[j++] = color.cbcolor;
				yuv->v[k++] = color.crcolor;
			}
		}
	}
}

int main(int argc,char*argv[])
{
	unsigned char *yuvdata = NULL, *y_data = NULL, *cb_data = NULL, *cr_data = NULL;
	unsigned char *temp_y_data = NULL,*temp_cb_data = NULL,*temp_cr_data = NULL, *temp_yuvdata = NULL;
	unsigned long int len = 0, len2 = 0;
	unsigned int i = 0, j = 0;
	yuvformat yuv;

	unsigned int width = (unsigned int)IMAGE_WIDTH;
	unsigned int height = (unsigned int)IMAGE_HEIGHT;
	int k = 0;
	colortype color;
	unsigned long int ylen=0,cblen=0,crlen=0;

	printf("Enter number of movable pages : ");
	scanf("%ld",&movablepages);
	printf("Enter number of reclaimable pages : ");
	scanf("%ld",&reclaimablepages);

	printf("Image Width  = %u\n",width);
	printf("Image Height = %u\n",height);

	fp = fopen("PageStateK32.yuv","wb");
	if(fp == NULL) 
	{
		perror(":ERROR:fopen failed for PageStateK32.yuv : ");
		exit(-1);
	}
	len = (width*height*3)>>1;
	yuvdata = (unsigned char*)malloc(sizeof(unsigned char)*(len));
	memset(yuvdata,0x00,len);
	temp_yuvdata = yuvdata;

	yuv.y = yuvdata;
        yuv.u = yuvdata + (width*height);
        yuv.v = yuvdata + (width*height) + (width*height)/4;
        yuv.width = width;
        yuv.height = height;

        color.ycolor = BLACK_YCOLOR;
        color.cbcolor = BLACK_CBCOLOR;
        color.crcolor = BLACK_CRCOLOR;
        create_background(&yuv,color);
	printf("Background image.....created !\n");

	yuv.y  = yuvdata + (Y_BLK_SPACING*width) + Y_BLK_SPACING;
	yuv.u = yuvdata + (width * height)  + (CBCR_BLK_SPACING * (width/2)) + CBCR_BLK_SPACING;
	yuv.v = yuvdata + (width * height)  + ((width/2) * (height/2)) + CBCR_BLK_SPACING * (width/2) + CBCR_BLK_SPACING;

	//yuv.y = y_data;
	//yuv.u = cb_data;
	//yuv.v = cr_data;
	yuv.width = width;
	yuv.height = height;
	create_blocks(&yuv);
	printf("image boundary creation...done!\n");
	
	//fwrite(yuvdata,1,len,fp);
	fwrite(yuvdata,len,1,fp);

	printf("Done...!\n");
	free(yuvdata);
	fclose(fp);

	return 0;
}



