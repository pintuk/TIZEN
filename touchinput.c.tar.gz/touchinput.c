/*
 * touchinput.c - program from generating touch event
 *
 * Author:
 *	Praveen BP <bp.praveen@samsung.com>
 *
 * Info:
 * - To build this sourcefile as part of toolbox no change is required.
 * - To build it as standalone executable define CONFIG_STANDALONE_EXE.
 * - To disable touch boost comment the macro ENABLE_TOUCH_BOOST.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <fcntl.h>
#include <errno.h>
#include <linux/input.h>


#define ADD_EVENT(t, c, v)	{ \
    .type = t,	\
    .code = c,	\
    .value = v,	\
}

struct input_event events[] = {
    ADD_EVENT(3, 0x39, 0x00),
    ADD_EVENT(3, 0x35, 0x00),
    ADD_EVENT(3, 0x36, 0x00),
    ADD_EVENT(3, 0x30, 0x20),
    ADD_EVENT(3, 0x3a, 0x06),
    ADD_EVENT(0, 0x00, 0x00),
    ADD_EVENT(3, 0x39, 0xffffffff),
    ADD_EVENT(0, 0x00, 0x00),
};

static void send_event(int fd, struct input_event *evt)
{
    int ret = write(fd, evt, sizeof(struct input_event));
    if (ret < (int)sizeof(struct input_event))
        fprintf(stderr, "write event failed, %s\n", strerror(errno));
}

int touchinput_main(int argc, char *argv[])
{
    int i, fd, delay=0, rel=0;
	
	
	for (i=0;i<argc; i++)
	{
	  printf("i=[%d],value=[%s]\n",i,argv[i]);
	}

    fd = open(argv[1], O_RDWR);
    if (fd < 0) {
        fprintf(stderr, "could not open %s, %s\n",
			argv[1], strerror(errno));
        return 1;
    }

    for (i = 0; i < 8; i++)
        memset(&events[i].time, 0x0, sizeof(struct timeval));

    /* Update x and y coordinate */
    events[1].value = atoi(argv[2]);
    events[2].value = atoi(argv[3]);
	delay = atoi(argv[4]);
	rel = atoi(argv[5]);
	
    send_event(fd, &events[0]);
	send_event(fd, &events[1]);
    send_event(fd, &events[2]);
    send_event(fd, &events[3]);
    send_event(fd, &events[4]);
	
	/* Press event */
    if(rel) 
		send_event(fd, &events[5]);
	send_event(fd, &events[6]);
	/* release event */
	if(!rel) {
		sleep((delay));
		send_event(fd, &events[7]);
	}
    /* Give some delay. Just in case if touch input events are given
     * back to back. 200ms is selected because, on T0 the total execution
     * time becomes ~0.5 seconds
     */

    usleep(200000);
    close(fd);
    return 0;
}

