#!/bin/bash

if [ "$1" = "" ]
then
	echo "Please specify the profile to build..."
	echo "./build.sh tizen_common"
	exit
fi

# Now tizen common profile can be build only on Linux 64-bit machine
# To build it on 32-bit machine, we need to change the <profile>.conf file under:
# /home/pintu/GBS-ROOT/local/BUILD-ROOTS/scratch.armv7l.0/tizen_common.conf
# Change: build_hostarch x86_64 => to x86, at all place in this conf file
# Then copy this file locally and use -D option to build

gbs build -A armv7l --include-all --profile=$1 -D ./tizen_common.conf
rc=$?
if [ $rc -ne 0 ]
then
	echo "build failed..."
else
	echo "build success....copy the rpm"
	#rm -f *.rpm
	#cp -f /home/pintu/GBS-ROOT/local/repos/$1/armv7l/RPMS/bt-robot-server-0.0.0.1-1.armv7l.rpm .
fi

