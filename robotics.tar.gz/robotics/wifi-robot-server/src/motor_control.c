/* motor_control.c
 *
 * Copyright (c) 2017 Samsung Electronics, Inc.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#include <stdio.h>
#include <unistd.h>
#include "gpioutils.h"
#include "motor_control.h"

void motor_stop(void)
{
	gpio_set_value(MOTORA_1, 0);
	gpio_set_value(MOTORA_2, 0);
	gpio_set_value(MOTORB_1, 0);
	gpio_set_value(MOTORB_2, 0);
	fprintf(stderr, "Motor Stopped....\n");
	//usleep(10000);
	//dlog_print(DLOG_INFO, LOG_TAG, "Motor Stopped....");
}

void send_to_motor(char c)
{
	switch (c) {
	case 'F':
	case 'f':
		motor_stop();
		gpio_set_value(MOTORA_1, 1);
		gpio_set_value(MOTORA_2, 0);
		gpio_set_value(MOTORB_1, 1);
		gpio_set_value(MOTORB_2, 0);
		fprintf(stderr, "Moving Forward....\n");
		//dlog_print(DLOG_INFO, LOG_TAG, "Moving Forward....");
		break;

	case 'B':
	case 'b':
		motor_stop();
		gpio_set_value(MOTORA_1, 0);
		gpio_set_value(MOTORA_2, 1);
		gpio_set_value(MOTORB_1, 0);
		gpio_set_value(MOTORB_2, 1);
		fprintf(stderr, "Moving Back....\n");
		//dlog_print(DLOG_INFO, LOG_TAG, "Moving Back....");
		break;

	case 'L':
	case 'l':
		motor_stop();
		gpio_set_value(MOTORA_1, 0);
		gpio_set_value(MOTORA_2, 0);
		gpio_set_value(MOTORB_1, 1);
		gpio_set_value(MOTORB_2, 0);
		fprintf(stderr, "Moving Left....\n");
		usleep(200 * 1000);
		motor_stop();
		//dlog_print(DLOG_INFO, LOG_TAG, "Moving Left....");
		break;

	case 'R':
	case 'r':
		motor_stop();
		gpio_set_value(MOTORA_1, 1);
		gpio_set_value(MOTORA_2, 0);
		gpio_set_value(MOTORB_1, 0);
		gpio_set_value(MOTORB_2, 0);
		fprintf(stderr, "Moving Right....\n");
		usleep(200 * 1000);
		motor_stop();
		//dlog_print(DLOG_INFO, LOG_TAG, "Moving Right....");
		break;

	case 'S':
	case 's':
		fprintf(stderr, "Stopping....\n");
		//dlog_print(DLOG_INFO, LOG_TAG, "Stopping....");
		motor_stop();
		break;
	}
}

void motor_init()
{
	gpio_export(MOTORA_1);
	gpio_direction(MOTORA_1, 1);

	gpio_export(MOTORA_2);
	gpio_direction(MOTORA_2, 1);

	gpio_export(MOTORB_1);
	gpio_direction(MOTORB_1, 1);

	gpio_export(MOTORB_2);
	gpio_direction(MOTORB_2, 1);

	fprintf(stderr, "motor init - done\n");
	//dlog_print(DLOG_INFO, LOG_TAG, "motor init - done");
}


void motor_uninit()
{
	motor_stop();

	gpio_unexport(MOTORA_1);

	gpio_unexport(MOTORA_2);

	gpio_unexport(MOTORB_1);

	gpio_unexport(MOTORB_2);
	fprintf(stderr, "motor uninit - done\n");
	//dlog_print(DLOG_INFO, LOG_TAG, "motor uninit - done");
}

