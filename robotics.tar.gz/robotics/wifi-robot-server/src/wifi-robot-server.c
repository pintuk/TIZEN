/* wifi-robot-server.c
 *
 * Copyright (c) 2017 Samsung Electronics, Inc.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#include <stdio.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
#include <netinet/in.h>
#include "motor_control.h"
#include "proxi_sensor.h"
#include "led_control.h"
#include "switch_control.h"
#include "ldr_control.h"

#define PORT 8080


void wifi_disconnect(void)
{
	motor_uninit();
	proxi_uninit();
	//ldr_uninit();
}


void wifi_connect(void)
{
	motor_init();
	proxi_init();
	//ldr_init();
}


void wifi_init(int *server_fd)
{
	struct sockaddr_in address;
	int addrlen;
	int opt = 1;
	int bind_cb;
	int listen_cb;

	addrlen = sizeof(address);
	*server_fd = socket(AF_INET, SOCK_STREAM, 0);
	if (*server_fd <= 0) {
		fprintf(stderr, "%s: socket failed: %s\n",
			__func__, strerror(errno));
		exit(EXIT_FAILURE);
	}
	if (setsockopt(*server_fd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT,
			&opt, sizeof(opt))) {
		fprintf(stderr, "%s: setsockopt failed: %s\n",
			__func__, strerror(errno));
		close(*server_fd);
		exit(EXIT_FAILURE);
	}
	address.sin_family = AF_INET;
	address.sin_addr.s_addr = INADDR_ANY;
	address.sin_port = htons(PORT);

	bind_cb = bind(*server_fd, (struct sockaddr *)&address, sizeof(address));
	if (bind_cb < 0) {
		fprintf(stderr, "%s: bind failed: %s\n",
			__func__, strerror(errno));
		close(*server_fd);
		exit(EXIT_FAILURE);
	}
	listen_cb = listen(*server_fd, 1);
	if (listen_cb < 0) {
		fprintf(stderr, "%s: listen failed: %s\n",
			__func__, strerror(errno));
		close(*server_fd);
		exit(EXIT_FAILURE);
	}
}

void wifi_uninit(int server_fd)
{
	if (server_fd)
		close(server_fd);
}

int main(int argc, char const *argv[])
{
	int sockfd;
	char data[255];
	int ret = -1;
	int isconnected = 0;

	wifi_init(&sockfd);
	if (sockfd < 0) {
		fprintf(stderr,"wifi_init failed\n");
		exit(EXIT_FAILURE);
	}

	led_init();//red LED;//green LED
	switch_init();
	//ldr_init();
	/* Turn on RED LED */
	led_write(LED_RED_PIN, 1);
	led_write(LED_GREEN_PIN, 0);

	while (1) {
		char val;
		int newsockfd;
		int addrlen = 0;
		struct sockaddr_in address;

		if (isconnected == 0) {
			newsockfd = accept(sockfd, (struct sockaddr *)&address, (socklen_t *)&addrlen);
			if (newsockfd < 0) {
				fprintf(stderr, "Error: accept failed : %s\n",
					strerror(errno));
				continue;
			}
		}
		ret = read(newsockfd, &data, 255);
		if (ret < 0) {
			fprintf(stderr, "ERROR: %s: read failed\n", __func__);
			continue;
		}
		val = data[0];
		printf("Got: %c\n",val);
		if ((val == 'c' || val == 'C') && isconnected == 0) {
			printf("Robot connected....\n");
			wifi_connect();
			isconnected = 1;
			/* Turn on GREEN LED */
			led_write(LED_RED_PIN, 0);
			led_write(LED_GREEN_PIN, 1);
		} else if ((val == 'd' || val == 'D') && isconnected == 1) {
			printf("Robot disconnected....\n");
			wifi_disconnect();
			isconnected = 0;
			/* Turn on RED LED */
			led_write(LED_RED_PIN, 1);
			led_write(LED_GREEN_PIN, 0);
		} else {
			if (isconnected == 1 && val != 'd' && val != 'c') {
				printf("Command send to motor : %c\n", val);
				send_to_motor(val);
			}
		}
	}
	led_uninit();
	switch_uninit();
	wifi_uninit(sockfd);

#if 0
	while (1) {
		if (flag == 0) {
			//listen_cb = listen(sockfd, 3);
               		//if (listen_cb < 0) {
                       	//	perror("Listen");
                       	//	exit(EXIT_FAILURE);
               		//}	
               		newsockfd = accept(sockfd, (struct sockaddr *)&address, (socklen_t *)&addrlen);
               		if (newsockfd < 0) {
                       		perror("Accept Failure");
                       		exit(EXIT_FAILURE);
			}
			flag = 1;
			motor_init();
               	} else {
		valread = read(newsockfd, buffer, 1024);
		if (valread == 1) {
			if (buffer[0] == 'd') {
				motor_uninit();
				flag = 0;
			} else {
			send_to_motor(buffer[0]);
			}
		}
	}
	}
}
#endif
	return 0;
}
