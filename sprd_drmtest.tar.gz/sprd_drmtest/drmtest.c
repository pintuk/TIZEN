#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <sys/poll.h>
#include <sys/time.h>
#include <sys/mman.h>
#include <compiler.h>

#include "sprd_drm.h"

#define LOG(fmt, args...)       \
        printf("%s:"fmt, __func__, ##args);

#define MSMTEST_MEM_WIDTH 736
#define MSMTEST_MEM_HEIGHT 1280

int ov_fd;

void write_buffer(void *buffer, unsigned long len)
{
        int i;
        unsigned char buf = 0x00;
        unsigned char *ptr = (unsigned char *)buffer;

        buf = ptr[0];
        printf("<%s>: Buffer Content: \n", __func__);
        for(i=0; i<len; i++) {
                ptr[i] = buf;
                printf("0x%x ", ptr[i]);
        }
        printf("Data written\n\n");
}

void read_buffer(void *buffer, unsigned long len)
{
        int i;
        unsigned char *ptr = (unsigned char *)buffer;

        printf("<%s>: Buffer content: \n", __func__);
        for(i=0; i<len; i++) {
                printf("0x%x ", ptr[i]);
        }
        printf("\n\n");
}

int sprd_gem_create(int fd, uint32_t size, uint32_t *handle)
{
        int ret;
        struct drm_sprd_gem_create req = {
                .size = size,
		.flags = SPRD_BO_CONTIG ,
        };

        ret = ioctl(fd, DRM_IOCTL_SPRD_GEM_CREATE, &req);
        if (ret) {
                fprintf(stderr, "%s:failed create gem handle. error[%s]\n",
                        __func__, strerror(errno));
                return ret;
        }

        *handle = req.handle;

        LOG("size[%d]handle[%d]\n", (unsigned int)req.size,(unsigned int)req.handle);

        return 0;
}

int sprd_gem_close(int dri_fd, uint32_t handle)
{
        int ret;
        struct drm_gem_close req = {
                .handle = handle,
        };

        LOG("handle[%d]\n", handle);

        ret = ioctl(dri_fd, DRM_IOCTL_GEM_CLOSE, &req);
        if (ret) {
                fprintf(stderr, "%s:failed gem close. error[%s]\n",
                        __func__, strerror(errno));
                return ret;
        }

        return 0;
}

int sprd_gem_get_fd(int dri_fd, uint32_t handle, uint32_t *fd)
{
        int ret;
//        struct drm_sprd_gem_get_ion_fd req = {
//                .handle = handle,
//        };
	struct drm_prime_handle req =  {
		.handle = handle,
	};
        //ret = ioctl(dri_fd, DRM_IOCTL_SPRD_GEM_GET_ION_FD, &req);
        ret = ioctl(dri_fd, DRM_IOCTL_PRIME_HANDLE_TO_FD, &req);
        if (ret) {
                fprintf(stderr, "%s:failed get ion fd from handle. error[%s]\n",
                        __func__, strerror(errno));
                return ret;
        }

        *fd = req.fd;

        LOG("handle[%d]ion_fd[%d]\n", req.handle, req.fd);

        return 0;
}

static void *msm_gem_alloc_framebuffer(int dri_fd, int *ret_handle, int size,  int *ret_ion_fd)
{
        int ret;
        uint32_t handle, ion_fd;
        uint64_t offset;
        void *virtaddr;
	int fbfd;
	fbfd = open("/dev/fb0", O_RDWR);
        if (fbfd == -1) {
                perror("Error: cannot open framebuffer device");
                exit(1);
        }

        ret = sprd_gem_create(dri_fd, size, &handle);
        if (ret) {
                fprintf(stderr, "%s:failed create gem handle. error[%s]\n",
                        __func__, strerror(errno));
                return NULL;
        }

        LOG("handle[%d]\n", handle);

/*      ret = sprd_gem_setmemtype(dri_fd, handle, type);
        if (ret) {
                fprintf(stderr, "%s:failed set memory type. error[%s]\n",
                        __func__, strerror(errno));
                return NULL;
        }
        ret = sprd_gem_alloc(dri_fd, handle, &offset);
        if (ret) {
                fprintf(stderr, "%s:failed mmap. error[%s]\n",
                        __func__, strerror(errno));
                return NULL;
        }
*/

        ret = sprd_gem_get_fd(dri_fd, handle, &ion_fd);
        if (ret) {
                fprintf(stderr, "%s:failed get ion fd from handle. error[%s]\n",
                        __func__, strerror(errno));
                return NULL;
        }
	
	ov_fd = ion_fd;	
	sprd_overlay_test(fbfd);
		
        virtaddr = mmap(0, size , PROT_READ | PROT_WRITE, MAP_SHARED, ion_fd, 0);
        if (virtaddr == MAP_FAILED) {
                fprintf(stderr, "%s:failed mmap. error[%s]\n",
                        __func__, strerror(errno));
                return NULL;
        }

/*	struct drm_sprd_gem_mmap req = {
                        .handle = handle,
                        .size   = size,
                };
	
	if (ioctl(dri_fd, DRM_IOCTL_SPRD_GEM_MMAP, &req))
        {
		fprintf(stderr, "failed to mmap[%s].\n",
                                strerror(errno));
                        return NULL;
	}	
	virtaddr = req.mapped;
*/
        *ret_handle = handle;
        *ret_ion_fd = ion_fd;

        return virtaddr;
}

static int msm_gem_free_framebuffer(int dri_fd, int handle)
{
        int ret;

        ret  = sprd_gem_close(dri_fd, handle);
        if (ret) {
                fprintf(stderr, "%s:failed gem close. error[%s]\n",
                        __func__, strerror(errno));
                return ret;
        }

        return 0;
}

static int msm_gem_alloc_fill_n_get_handle(int dri_fd, int color)
{
        int handle, pitches, size, ion_fd, stride;
        void *virtaddr = NULL;
//        drm_gem_flink flink;
        stride = 4 * MSMTEST_MEM_WIDTH;
        pitches = MSMTEST_MEM_HEIGHT * stride;
        size = pitches;

        virtaddr = msm_gem_alloc_framebuffer(dri_fd, &handle, size, &ion_fd);
        if (!virtaddr) {
                fprintf(stderr, "%s:failed gem alloc framebuffer. error[%s]\n",
                        __func__, strerror(errno));
                return -ENOMEM;
        }

        /* drawing */
//      if (color < 0)
//              msm_fill_color_bar(virtaddr, MSMTEST_MEM_WIDTH, MSMTEST_MEM_HEIGHT, XRGB888_BPP, 0);
//      else
                memset(virtaddr, color, stride * MSMTEST_MEM_HEIGHT);

        getchar();

	read_buffer(virtaddr,10);
//        flink.handle=handle;
//        ret = ioctl(dri_fd, DRM_IOCTL_GEM_FLINK, &flink);
//        if(ret != 0)
//                goto out;

//out:
//        ret = msm_gem_free_framebuffer(dri_fd, handle);
//        if (ret) {
//                fprintf(stderr, "%s:failed gem free framebuffer. error[%s]\n",
//                        __func__, strerror(errno));
//                return ret;
//        }

        return handle;
}


int main(int argc, char *argv[])
{
	int ret = -1;
	int dri_fd, gem_handle,size,stride;
	struct drm_gem_flink flink;
	struct drm_gem_open gem_open;
	void *virtaddr;
	uint32_t ion_fd;
	stride = 4 * MSMTEST_MEM_WIDTH;
        size = MSMTEST_MEM_HEIGHT * stride;
	/* This is server: opne the socket connection first */
	printf("------------ CREATING GEM -------------\n");
	dri_fd = open("/dev/dri/card0", O_RDWR);
        if (dri_fd < 0) {
                LOG("failed to get drm fd.\n");
                return -1;
        } else {
                LOG("drm success.\n");
        }
	gem_handle = msm_gem_alloc_fill_n_get_handle(dri_fd, 1);
	flink.handle = gem_handle;	
	ret = ioctl(dri_fd, DRM_IOCTL_GEM_FLINK, &flink);
	if(ret != 0){
		printf("DRM_IOCTL_GEM_FLINK failed\n");
		goto err;
	}
		printf("DRM_IOCTL_GEM_FLINK created\n");
	gem_open.name=flink.name;
	ret = ioctl(dri_fd, DRM_IOCTL_GEM_OPEN, &gem_open);
        if(ret == 0){
                printf("REceived handle\n");
                gem_handle = gem_open.handle;
        }else{
                printf("GEM_OPEN failed\n");
                goto err;
        }
        
        ret = sprd_gem_get_fd(dri_fd, gem_handle, &ion_fd);
        if (ret) {
                fprintf(stderr, "%s:failed get ion fd from handle. error[%s]\n",
                        __func__, strerror(errno));
                return -1;
        }
        virtaddr = mmap(0, size, PROT_READ | PROT_WRITE, MAP_SHARED, ion_fd, 0);
        if (virtaddr == MAP_FAILED) {
                fprintf(stderr, "%s:failed mmap. error[%s]\n",
                        __func__, strerror(errno));
                return -1;
        }

        read_buffer(virtaddr , 10);     
        printf("=====================================================\n");

	msm_gem_free_framebuffer(dri_fd, gem_handle);

	printf("-----------------------------------------------\n");
err:
	return 0;
}

