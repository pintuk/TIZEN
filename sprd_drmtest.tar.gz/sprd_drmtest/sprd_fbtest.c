#include "sprd_fbtest.h"

struct fb_var_screeninfo sprd_vinfo;
struct fb_fix_screeninfo sprd_finfo;
extern int ov_fd;
int sprd_overlay_test(int fbfd)
{
	sprd_overlay_info ov_info;
	memset(&ov_info, 0 , sizeof(sprd_overlay_info));
	ov_info.layer_index = SPRD_LAYER_IMG;
	ov_info.rect.x = 0;
	ov_info.rect.y = 0;
	ov_info.rect.w = 240;
	ov_info.rect.h = 300;
	ov_info.data_type = SPRD_DATA_TYPE_RGB888;
	ov_info.ion_fd = ov_fd;//SPRD_DATA_TYPE_RGB888;
	//ov_info.buffer = (unsigned char *)malloc
			 //(sizeof(ov_info.rect.w * ov_info.rect.h * 32));
//	memset(ov_info.buffer, 255,
//			sizeof(ov_info.rect.w * ov_info.rect.h * 32));

	if (ioctl(fbfd, SPRD_FB_SET_OVERLAY, &ov_info) == -1) {
		perror("Error set overlay");
		exit(1);
	}
	if (ioctl(fbfd, SPRD_FB_DISPLAY_OVERLAY, &ov_info) == -1) {
		perror("Error set overlay");
		exit(1);
	}
	if (ioctl(fbfd, FBIOPAN_DISPLAY, &sprd_vinfo)) {
		perror("Error pan Display");
		exit(1);
	}

	printf("[SPRD] Display overlay successfull \n");

	return 0;
}

static int sprd_refresh_rate_test(int fbfd)
{
	struct timespec start, end;
	double fps;
	int i = 0;

	clock_gettime(CLOCK_MONOTONIC, &start);
	while( i < 1000 )
	{
		if (ioctl(fbfd, FBIOPAN_DISPLAY, &sprd_vinfo)){
			perror("PAN Display failed");
			exit(1);
		}
		i++;
	}
	clock_gettime(CLOCK_MONOTONIC, &end);
	end.tv_sec -= start.tv_sec;
	end.tv_nsec -= start.tv_nsec;

	if (end.tv_nsec < 0) {
		end.tv_sec--;
		end.tv_nsec += 1000000000;
	}
	fps = i / (end.tv_sec + end.tv_nsec / 1000000000.);
	printf("[SPRD] %u vsync interrupts in %lu.%06lu s, %f Hz\n",
			i, end.tv_sec, end.tv_nsec / 1000, fps);
	return 0;
}

static int sprd_blank_unblank_test(int fbfd)
{
	if (ioctl(fbfd, FBIOBLANK, FB_BLANK_UNBLANK) == -1) {
		perror("Error FBIOBLANK");
		exit(1);
	}
	printf("[SPRD] Blank Unblank successfull\n");
	return 0;
}

static int sprd_get_screen_info_test(int fbfd)
{
	if (ioctl(fbfd, FBIOGET_FSCREENINFO, &sprd_finfo) == -1) {
		perror("Error reading fixed information");
		exit(1);
	}

	if (ioctl(fbfd, FBIOGET_VSCREENINFO, &sprd_vinfo) == -1) {
		perror("Error reading variable information");
		exit(1);
	}

	printf("[SPRD] Resolution : %dx%d, BPP : %dbpp\n", sprd_vinfo.xres, 
			sprd_vinfo.yres, sprd_vinfo.bits_per_pixel);

	return 0;
}

static int sprd_fb_test(int fbfd)
{
	long int screensize = 0;
	char *fbp = 0;
	int x = 0, y = 0;
	long int location = 0;

	sprd_get_screen_info_test(fbfd);
	screensize = sprd_vinfo.xres * sprd_vinfo.yres * sprd_vinfo.bits_per_pixel / 8;

	fbp = (char *)mmap(0, screensize, PROT_READ | PROT_WRITE, MAP_SHARED, fbfd, 0);
	if ((int)fbp == -1) {
		perror("Error map framebuffer device to memory");
		exit(1);
	}

	// Open source code used below to dump some junk data
	sprd_vinfo.xoffset = 0;
	sprd_vinfo.yoffset = 0;
	x = 100; y = 100; 
	for (y = 0; y < 320; y++)
		for (x = 0; x < 240; x++) {

			location = (x+sprd_vinfo.xoffset) * (sprd_vinfo.bits_per_pixel/8) +
				(y+sprd_vinfo.yoffset) * sprd_finfo.line_length;

			*(fbp + location) = 100;        // Some blue
			*(fbp + location + 1) = 15+(x-100)/2;     // A little green
			*(fbp + location + 2) = 200-(y-100)/5;    // A lot of red
			*(fbp + location + 3) = 0;      // No transparency
			location += 4;
		}
	sleep(5);
	munmap(fbp, screensize);

	return 0;
}

void usage(int fbfd){
	printf ("Usage: %s [options]\n"
			"Options: -o ===> Overlay test\n"
			"         -f ===> Basic Framebuffer test\n"
			"         -b ===> Blank Unblank test\n"
			"         -i ===> Display panel info  test\n"
			"         -r ===> Calculate refresh rate for 1000 oprns\n"
			"\nExample: sprd_fbtest -f\n");
	close(fbfd);
	exit(1);
}
#if 0
int main(int argc,char **argv)
{
	int fbfd = 0;
	int optchar;

	fbfd = open("/dev/fb0", O_RDWR);
	if (fbfd == -1) {
		perror("Error: cannot open framebuffer device");
		exit(1);
	}

	if (argc != 2)
		usage(fbfd);

	optchar = getopt(argc,argv,"ofbir");
	switch(optchar) {
	case 'o':
		if(!sprd_overlay_test(fbfd))
			printf("[SPRD] Overlay operations passed\n");
		break;
	case 'f':
		if(!sprd_fb_test(fbfd))
			printf("[SPRD] Fb test operations passed\n");
		break;
	case 'b':
		if(!sprd_blank_unblank_test(fbfd))
			printf("[SPRD] Blank unblank operations passed\n");
		break;
	case 'r':
		if(!sprd_refresh_rate_test(fbfd))
			printf("[SPRD] Vsync test passed\n");
		break;
	case 'i':
		if(!sprd_get_screen_info_test(fbfd))
			printf("[SPRD] Get screen info operations passed\n");
		break;
	case '?':
		usage(fbfd);
	}
	close(fbfd);
	return 0;
}
#endif
