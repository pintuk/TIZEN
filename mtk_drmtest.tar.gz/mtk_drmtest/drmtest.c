#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <sys/poll.h>
#include <sys/time.h>
#include <sys/mman.h>
#include <compiler.h>
#include "drm.h"

#include "mtk_drm.h"

#define LOG(fmt, args...)       \
        printf("%s:"fmt, __func__, ##args);

#define MEM_WIDTH 320
#define MEM_HEIGHT 480
#define SIZE 0x1000000   //16MB
int ov_fd;

void write_buffer(void *buffer, unsigned long len)
{
        int i;
        //unsigned char buf = rand() % 100 ;
        unsigned char buf = 0xff ;
        unsigned char *ptr = (unsigned char *)buffer;

//        printf("<%s>: Buffer Content: \n", __func__);
        for(i=0; i<len; i++) {
                ptr[i] = buf;
 //               printf("0x%x ", ptr[i]);
        }
        printf("Data written\n\n");
}

void read_buffer(void *buffer, unsigned long len)
{
        int i;
        unsigned char *ptr = (unsigned char *)buffer;

        printf("<%s>: Buffer content: \n", __func__);
        for(i=0; i<len; i++) {
                printf("0x%x ", ptr[i]);
        }
        printf("\n\n");
}

int mtk_gem_create(int fd, uint32_t size, uint32_t *handle)
{
        int ret;
        struct drm_mtk_gem_create req = {
                .size = size,
		.flags = 0,
        };

        ret = ioctl(fd, DRM_IOCTL_MTK_GEM_CREATE, &req);
        if (ret) {
                fprintf(stderr, "%s:failed create gem handle. error[%s]\n",
                        __func__, strerror(errno));
                return ret;
        }

        *handle = req.handle;

        LOG("size[%d]handle[%d]\n", (unsigned int)req.size,(unsigned int)req.handle);

        return 0;
}

int mtk_gem_close(int dri_fd, uint32_t handle)
{
        int ret;
        struct drm_gem_close req = {
                .handle = handle,
        };

        LOG("handle[%d]\n", handle);

        ret = ioctl(dri_fd, DRM_IOCTL_GEM_CLOSE, &req);
        if (ret) {
                fprintf(stderr, "%s:failed gem close. error[%s]\n",
                        __func__, strerror(errno));
                return ret;
        }

        return 0;
}

int mtk_gem_get_handle (int dri_fd,uint32_t fd,uint32_t *handle){

	int ret;
	struct drm_prime_handle req =  {
		.fd = fd,
	};
	ret = ioctl(dri_fd, DRM_IOCTL_PRIME_FD_TO_HANDLE, &req);
        if (ret) {
                fprintf(stderr, "%s:failed get handle from ion fd . error[%s]\n",
                        __func__, strerror(errno));
                return ret;
        }

        *handle = req.handle;

        LOG("handle[%d]ion_fd[%d]\n", req.handle, req.fd);

        return 0;

}

int mtk_gem_get_fd(int dri_fd, uint32_t handle, uint32_t *fd)
{
        int ret;
	struct drm_prime_handle req =  {
		.handle = handle,
	};
        ret = ioctl(dri_fd, DRM_IOCTL_PRIME_HANDLE_TO_FD, &req);
        if (ret) {
                fprintf(stderr, "%s:failed get ion fd from handle. error[%s]\n",
                        __func__, strerror(errno));
                return ret;
        }

        *fd = req.fd;

        LOG("handle[%d]ion_fd[%d]\n", req.handle, req.fd);

        return 0;
}

static void *msm_gem_alloc_framebuffer(int dri_fd, int *ret_handle, int size,  int *ret_ion_fd)
{
        int ret;
        uint32_t handle, ion_fd;
        void *virtaddr;

        ret = mtk_gem_create(dri_fd, size, &handle);
        if (ret) {
                fprintf(stderr,"%s:failed create gem handle. error[%s]\n",
                        __func__, strerror(errno));
                return NULL;
        }
	//getchar();
        LOG("handle[%d]\n", handle);

        ret = mtk_gem_get_fd(dri_fd, handle, &ion_fd);
        if (ret) {
                fprintf(stderr, "%s:failed get ion fd from handle. error[%s]\n",
                        __func__, strerror(errno));
                return NULL;
        }
	
        fprintf(stderr, "[1]%s: handle = %x fd = %d \n", __func__, handle, ion_fd);
#if 0			
        virtaddr = mmap(0, size , PROT_READ | PROT_WRITE, MAP_SHARED, ion_fd, 0);
        if (virtaddr == MAP_FAILED) {
                fprintf(stderr, "%s:failed mmap. error[%s]\n",
                        __func__, strerror(errno));
                return NULL;
        }
#else
        struct drm_mtk_gem_mmap req = {
                        .handle = handle,
                        .size   = size,
                };

        if (ioctl(dri_fd, DRM_IOCTL_MTK_GEM_MMAP, &req))
        {
                fprintf(stderr, "failed to mmap[%s].\n",
                                strerror(errno));
                        return NULL;
        }
        virtaddr = req.mapped;
#endif
	read_buffer(virtaddr,10);
	write_buffer(virtaddr,size);
	read_buffer(virtaddr,10);
	
        *ret_handle = handle;
        *ret_ion_fd = ion_fd;
	//getchar();
        return virtaddr;
}

static int msm_gem_free_framebuffer(int dri_fd, int handle)
{
        int ret;

        ret  = mtk_gem_close(dri_fd, handle);
        if (ret) {
                fprintf(stderr, "%s:failed gem close. error[%s]\n",
                        __func__, strerror(errno));
                return ret;
        }

        return 0;
}

static int msm_gem_alloc_fill_n_get_handle(int dri_fd, int color, int *ionfd)
{
        int handle, size, ion_fd;
        void *virtaddr = NULL;
        size = SIZE;

        virtaddr = msm_gem_alloc_framebuffer(dri_fd, &handle, size, &ion_fd);
        if (!virtaddr) {
                fprintf(stderr, "%s:failed gem alloc framebuffer. error[%s]\n",
                        __func__, strerror(errno));
                return -ENOMEM;
        }
	munmap(virtaddr,size);
        /* drawing */
	*ionfd = ion_fd;
        return handle;
}


int main(int argc, char *argv[])
{
	int dri_fd,ion_fd = 0,gem_handle=0,ret=-1;
	void *virtaddr;
        uint32_t ion_fd_1=0,size,gem_handle_1=0;
	size=SIZE;
	printf("------------ CREATING GEM -------------\n");
	dri_fd = open("/dev/dri/card0", O_RDWR);
        if (dri_fd < 0) {
                LOG("failed to get drm fd.\n");
                return -1;
        } else {
                LOG("drm success.\n");
        }
	gem_handle = msm_gem_alloc_fill_n_get_handle(dri_fd, 1, &ion_fd);
	if( !gem_handle)
	{
		printf("Failed to get GEM_HANDLE\n");
		return -EINVAL;
	}
	printf("press enter to continue\n");
	getchar();
        printf("=====================================================\n");
	//-------------------------------------------------------------------------------------

        printf("ion_fd -> %d gem handle -> %d \n",(int)ion_fd,(int)gem_handle);  
        printf("-----------------------------------------------\n");
        ret = mtk_gem_get_handle(dri_fd, ion_fd , &gem_handle_1);
        if (ret) {
                fprintf(stderr, "%s:failed get handle from fd. error[%s]\n",
                        __func__, strerror(errno));
                return -1;
        }
        else 
                printf("%s:Success: get handle from fd.\n", __func__);

//-------------------------------------------------------------------------------------
        printf("gem handle_1 -> %d , ion_fd -> %d\n",gem_handle_1,ion_fd);  
        printf("-----------------------------------------------\n");
        ret = mtk_gem_get_fd(dri_fd, gem_handle_1, &ion_fd_1);
        if (ret) {
                fprintf(stderr, "%s:failed get ion fd from handle. error[%s]\n",
                        __func__, strerror(errno));
                return -1;
        }
        else 
        printf("gem handle_1 -> %d , ion_fd_1 -> %d\n",gem_handle_1,ion_fd_1);  
//-------------------------------------------------------------------------------------
        printf("-----------------------------------------------\n");
                
        virtaddr = mmap(0, size, PROT_READ | PROT_WRITE, MAP_SHARED, ion_fd_1, 0);
        if (virtaddr == MAP_FAILED) {
                fprintf(stderr, "%s:failed mmap. error[%s]\n",
                        __func__, strerror(errno));
                return -1;
        }
        printf("-----------------------------------------------\n");

        read_buffer(virtaddr , 10);     
        write_buffer(virtaddr , 10);     
        read_buffer(virtaddr , 10);     
        getchar();
        printf("=====================================================\n");
	munmap(virtaddr,size);
	close(ion_fd_1);
        msm_gem_free_framebuffer(dri_fd, gem_handle_1);
	getchar();
	close(ion_fd);
	msm_gem_free_framebuffer(dri_fd, gem_handle);
	printf("-------enter to close the app-------\n");
	getchar();
	return 0;
}

