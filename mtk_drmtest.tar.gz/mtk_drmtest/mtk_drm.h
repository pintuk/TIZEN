/* mtk_drm.h
 */

#ifndef _UAPI_MTK_DRM_H_
#define _UAPI_MTK_DRM_H_

#include <drm/drm.h>

/**
 * User-desired buffer creation information structure.
 *
 * @size: user-desired memory allocation size.
 *	- this size value would be page-aligned internally.
 * @flags: user request for setting memory type or cache attributes.
 * @handle: returned a handle to created gem object.
 *	- this handle will be set by gem module of kernel side.
 */
struct drm_mtk_gem_create {
	uint64_t size;
	unsigned int flags;
	unsigned int handle;
};

/**
 * A structure for getting buffer offset.
 *
 * @handle: a pointer to gem object created.
 * @pad: just padding to be 64-bit aligned.
 * @offset: relatived offset value of the memory region allocated.
 *	- this value should be set by user.
 */
struct drm_mtk_gem_map_off {
	unsigned int handle;
	unsigned int pad;
	uint64_t offset;
};

/**
 * A structure for mapping buffer.
 *
 * @handle: a handle to gem object created.
 * @pad: just padding to be 64-bit aligned.
 * @size: memory size to be mapped.
 * @mapped: having user virtual address mmaped.
 *	- this variable would be filled by mtk gem module
 *	of kernel side with user virtual address which is allocated
 *	by do_mmap().
 */
struct drm_mtk_gem_mmap {
	unsigned int handle;
	unsigned int pad;
	uint64_t size;
	uint64_t mapped;
};

/**
 * A structure to gem information.
 *
 * @handle: a handle to gem object created.
 * @flags: flag value including memory type and cache attribute and
 *	this value would be set by driver.
 * @size: size to memory region allocated by gem and this size would
 *	be set by driver.
 */
struct drm_mtk_gem_info {
	unsigned int handle;
	unsigned int flags;
	uint64_t size;
};

struct drm_mtk_gem_lock_handle {
        uint32_t handle;
        uint32_t pid;
};

struct drm_mtk_gem_unlock_handle {
        uint32_t handle;
};

/* memory type definitions. */
enum e_drm_mtk_gem_mem_type {
	/* Physically Continuous memory and used as default. */
	MTK_BO_CONTIG	= 0 << 0,
	/* Physically Non-Continuous memory. */
	MTK_BO_NONCONTIG	= 1 << 0,
	/* non-cachable mapping and used as default. */
	MTK_BO_NONCACHABLE	= 0 << 1,
	/* cachable mapping. */
	MTK_BO_CACHABLE	= 1 << 1,
	/* write-combine mapping. */
	MTK_BO_WC		= 1 << 2,
	MTK_BO_MASK		= MTK_BO_NONCONTIG | MTK_BO_CACHABLE |
					MTK_BO_WC,
};

#define DRM_MTK_GEM_CREATE		0x00
#define DRM_MTK_GEM_MAP_OFFSET	0x01
#define DRM_MTK_GEM_MMAP		0x02
/* Reserved 0x03 ~ 0x05 for mtk specific gem ioctl */
#define DRM_MTK_GEM_USERPTR            0x03
#define DRM_MTK_GEM_GET		0x04
#define DRM_MTK_GEM_LOCK_HANDLE 0x0B
#define DRM_MTK_GEM_UNLOCK_HANDLE 0x0C

#define DRM_IOCTL_MTK_GEM_CREATE		DRM_IOWR(DRM_COMMAND_BASE + \
		DRM_MTK_GEM_CREATE, struct drm_mtk_gem_create)
#define DRM_IOCTL_MTK_GEM_MAP_OFFSET	DRM_IOWR(DRM_COMMAND_BASE + \
		DRM_MTK_GEM_MAP_OFFSET, struct drm_mtk_gem_map_off)
#define DRM_IOCTL_MTK_GEM_MMAP	DRM_IOWR(DRM_COMMAND_BASE + \
		DRM_MTK_GEM_MMAP, struct drm_mtk_gem_mmap)
#define DRM_IOCTL_MTK_GEM_GET	DRM_IOWR(DRM_COMMAND_BASE + \
		DRM_MTK_GEM_GET,	struct drm_mtk_gem_info)
#define DRM_IOCTL_MTK_GEM_LOCK_HANDLE DRM_IOWR(DRM_COMMAND_BASE + \
                DRM_MTK_GEM_LOCK_HANDLE, struct drm_mtk_gem_lock_handle)
#define DRM_IOCTL_MTK_GEM_UNLOCK_HANDLE DRM_IOWR(DRM_COMMAND_BASE + \
                DRM_MTK_GEM_UNLOCK_HANDLE, struct drm_mtk_gem_unlock_handle)

#endif	/* _UAPI_MTK_DRM_H_ */
